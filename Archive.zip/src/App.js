import './App.css';
import NewProduct from './components/NewProduct';

function App() {
  return (
    <div className="App">
      <NewProduct />
    </div>
  );
}

export default App;
